
import React    from "react";
import { Formik, Form, Field, ErrorMessage } from 'formik';
import CourseDataService from "../service/CourseDataService";

const INSTRUCTOR = 'sp'
class CourseComponent extends React.Component {
    constructor(props){
      super(props)
      this.state={
          id: this.props.match.params.id, //url /courses/${id}. From the path parameter, we would want to capture the id. We can use this.props.match.params.id to get the id from path parameters.
          description : '' 
      }
      this.onSubmit = this.onSubmit.bind(this)
      this.validate= this.validate.bind(this)
    }

    componentDidMount(){
      console.log('Course component -',this.state.id)
      //eslint-disable-next-line
      if(this.state.id == -1){
        return
      }

      CourseDataService.retrieveCourse(INSTRUCTOR, this.state.id)
        .then( response => this.setState({
          description: response.data.description
          }) )
    }

    onSubmit(values) {
      let username = INSTRUCTOR

      let course = {
            id: this.state.id,
            description: values.description,
            targetDate: values.targetDate
      }

      if (this.state.id === -1) {
        CourseDataService.createCourse(username, course)
            .then(() => this.props.history.push('/courses')) //we are redirecting the user to the course listing page using this.props.history.push('/courses').
      } else {
        CourseDataService.updateCourse(username, this.state.id, course)
            .then(() => this.props.history.push('/courses'))
      }
      console.log(values);
    }

    
    validate(values){
      let errors = {}
      if(!values.description){
        console.log('errors.description= Enter a Description')
        errors.description= 'Enter a Description'
      } else if(values.description.length<5){
        console.log('errors.description= Enter atleast 5 characters in Descripition')
        errors.description='Enter atleast 5 characters in Descripition'
      }
      return errors
    }


    render() {
      // let { description, id } = this.state
      let { description, id} = this.state //let { description, id } = this.state is called destructing. This is similar to writing code shown below.
                                          //let description = this.state.description
                                          //let id = this.state.id
      return (
        <div>
            <h3>Course</h3>
            {/* <ErrorMessage name="description" component="div" className="alert alert-warning" /> */}
            <div className="container">
            {/* Initialing Formik with the values loaded from state */}
                <Formik initialValues={{ id, description }} onSubmit={this.onSubmit} 
                validateOnChange={false}
                validateOnBlur={false}
                validate={this.validate} //key snippet
                enableReinitialize={true}  // is needed to ensure that we can reload the form for existing todo
                > 
                    {
                        (props) => (
                            <Form>
                                <fieldset className="form-group">
                                    <label>Id</label>
                                    <Field className="form-control" type="text" name="id" disabled />
                                </fieldset>
                                <fieldset className="form-group">
                                    <label>Description</label>
                                    <Field className="form-control" type="text" name="description" />
                                </fieldset>
                                <button className="btn btn-success" type="submit">Save</button>
                            </Form>
                        )
                    }
                </Formik>

            </div>
        </div>
    )
  }

}

export default CourseComponent