import React    from 'react';
import ListCoursesComponent from '../ListCoursesComponent';
import CourseComponent from '../CourseComponent/CourseComponent';
import { Route, Switch, Link } from 'react-router';
import { BrowserRouter as Router } from 'react-router-dom'//react-router-dom doesn't export a Router, instead, it exports a BrowserRouter so you need to import { BrowserRouter as Router } from 'react-router-dom.

class IntructorApp extends React.Component {
  render() {
    return (
        <Router>
            <>
                <h1>Instructor Application</h1>
                <Switch>
                    <Route path="/" exact component={ListCoursesComponent} />
                    <Route path="/courses" exact component={ListCoursesComponent} />
                    <Route path="/courses/:id" component={CourseComponent} />
                    {/* http://localhost:3000/ takes you to home page
http://localhost:3000/courses takes you to course listing page
http://localhost:3000/courses/2 takes you to course page */}
                </Switch>
            </>
        </Router>
    )
}
}

export default IntructorApp;
