import ListCoursesComponent from "./ListCoursesComponent";
export default ListCoursesComponent;
