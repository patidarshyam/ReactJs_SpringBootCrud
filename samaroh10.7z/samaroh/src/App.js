import React from 'react';
import './App.css';
// import IntructorApp from'./InstructorApp/InstructorApp.jsx';
 import Test from './Components/TestComponent/Test.jsx';

function App() {
  return (
    <div className="App">
      {/* <IntructorApp />   */}
      <h1>my react app samaroh</h1>
      <Test/>
      
    </div>
  );
}

export default App;
