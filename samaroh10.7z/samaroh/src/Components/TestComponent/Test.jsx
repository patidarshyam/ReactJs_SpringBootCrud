import React    from "react";
import RecipeReviewCard from './Card.jsx';

class Test extends React.Component {

    constructor(props){
        super(props)
     }
 

  render() {
    console.log('render....')
    return (
      <div className="container">
      
        <div>
        <RecipeReviewCard />
        
        </div>
       
      </div>
      
  );
  }
}

export default Test;
