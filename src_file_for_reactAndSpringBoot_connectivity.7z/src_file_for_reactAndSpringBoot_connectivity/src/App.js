import React from 'react';
import './App.css';
import IntructorApp from'./IntructorApp';

function App() {
  return (
    <div className="App">
      <IntructorApp />  
    </div>
  );
}

export default App;
