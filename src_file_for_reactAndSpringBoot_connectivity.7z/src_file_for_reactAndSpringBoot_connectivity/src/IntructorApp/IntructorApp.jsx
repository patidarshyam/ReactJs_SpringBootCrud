import React    from "react";
import ListCoursesComponent from "../ListCoursesComponent";

class IntructorApp extends React.Component {
  render() {
    return (
      <div className="intructor-app">
        <h1>IntructorApp</h1>
        <ListCoursesComponent/>
      </div>
    );
  }
}

export default IntructorApp;
