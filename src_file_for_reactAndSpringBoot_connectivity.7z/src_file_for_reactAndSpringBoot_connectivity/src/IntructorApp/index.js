import IntructorApp from "./IntructorApp";
export default IntructorApp;
