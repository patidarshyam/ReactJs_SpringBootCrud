import React    from "react";
import CourseDataService from '../service/CourseDataService'

class ListCoursesComponent extends React.Component {

    constructor(props){
        super(props)
        this.state={
            courses :[],
            message : null
        }
        this.deleteCourseClicked = this.deleteCourseClicked.bind(this)
        this.refreshCourses= this.refreshCourses.bind(this);//Any method in a react component should be bound to this. 
    }
    // React defines a component lifecycle. componentDidMount will be called as soon as the component is mounted. We are calling refreshCourses as soon as a component is mounted.
    componentDidMount(){
        this.refreshCourses();
    }
//This method is to return all record
refreshCourses(){
        CourseDataService.retriveAllCources('INSTRUCTOR') //heardcode
        .then(  //This would make the call to the REST API. You can define how to process the response in the then method.
            response => {
                console.log(response);
                this.setState({courses: response.data}) //When the response comes back with data, we update the state.
            }
        )
    }
//This method will delete the data
    deleteCourseClicked(id) {
        CourseDataService.deleteCourse('INSTRUCTOR', id)
            .then(
                response => {
                    this.setState({ message: `Delete of course ${id} Successful` })
                    this.refreshCourses()
                }
            )
    
    }

  render() {
    console.log('render....')
    return (
      <div className="container">
      <h3>All Courses</h3>
      {/* if condition- this.state.message && <div> */}
    { this.state.message && <div className="alert alert-success">{this.state.message}</div> }
      <div className="container">
          <table className="table">
              <thead>
                  <tr>
                      <th>Id</th>
                      <th>Description</th>
                  </tr>
              </thead>
              {/* <tbody>
                  <tr>
                      <td>1</td>
                      <td>Learn Full stack with Spring Boot and Angular</td>
                  </tr>
              </tbody> */}

              <tbody>
                  {
                      this.state.courses.map( //Allow you to loop around a list of items and define how each item should be displayed.
                          course =>
                          <tr key={course.id}>
                                <td>{course.id}</td>
                                <td>{course.description}</td>
                                <td><button className="btn btn-warning" onClick={() => this.deleteCourseClicked(course.id)}>Delete</button></td>
                                {/* onClick={ () =>  this.deleteCourseClicked(course.id)> } */}
                          </tr>
                      )
                  }
              </tbody>
          </table>
      </div>
      </div>
  );
  }
}

export default ListCoursesComponent;
